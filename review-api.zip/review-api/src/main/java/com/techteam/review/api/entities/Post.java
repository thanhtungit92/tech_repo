package com.techteam.review.api.entities;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "post")
@Getter
@Setter
public class Post {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 100, nullable = false)
    private String topic;

    @Column(length = 1000, nullable = false)
    private String content;

    @Column(name = "image_url")
    private String imageUrl;

    @Column(name = "total_like")
    private Long totalLike;

    @Column(name = "total_subscribe")
    private Long totalSubscribe;
}
