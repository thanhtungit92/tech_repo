package com.techteam.review.api.services;

import com.techteam.review.api.*;
import com.techteam.review.api.entities.Post;
import com.techteam.review.api.repository.PostRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class PostService {
    @Autowired
    private PostRepository postRepository;

    public PostResponse createPost(PostRequest request) {
        Post post = new Post();
        post.setTopic(request.getTopic());
        post.setContent(request.getContent());
        post.setImageUrl(post.getImageUrl());
        post = postRepository.save(post);

        PostResponse.Builder builder = PostResponse.newBuilder().setId(post.getId()).setTopic(post.getTopic())
                .setContent(post.getContent());
        if (post.getImageUrl() != null) {
            builder.setImageUrl(post.getImageUrl());
        }

        if (post.getTotalLike() != null) {
            builder.setLike(post.getTotalLike());
        }

        if (post.getTotalLike() != null) {
            builder.setSubscribe(post.getTotalLike());
        }

        PostResponse response = builder.build();
        return response;
    }

    public PostResponse updatePost(PostRequest request) {
        Post post = postRepository.getById(request.getId());
        post.setTopic(request.getTopic());
        post.setContent(request.getContent());
        post.setImageUrl(post.getImageUrl());
        post = postRepository.save(post);
        PostResponse.Builder builder = PostResponse.newBuilder().setId(post.getId()).setTopic(post.getTopic())
                .setContent(post.getContent());
        if (post.getImageUrl() != null) {
            builder.setImageUrl(post.getImageUrl());
        }

        if (post.getTotalLike() != null) {
            builder.setLike(post.getTotalLike());
        }

        if (post.getTotalLike() != null) {
            builder.setSubscribe(post.getTotalLike());
        }

        PostResponse response = builder.build();

        return response;
    }

    public Response deletePost(PostDeleteRequest postDeleteRequest) {
        Post post = postRepository.getById(postDeleteRequest.getId());
        postRepository.delete(post);
        Response response = Response.newBuilder().setCode(200).setMessage("Delete Success!").build();

        return response;
    }

    public List<PostResponse> getAllPosts(PostQuery request) {
        List<Post> posts = postRepository.findAll();
        List<PostResponse> postResponses = new ArrayList<>();
        posts.forEach(post -> {
            PostResponse.Builder builder = PostResponse.newBuilder().setId(post.getId()).setTopic(post.getTopic())
                    .setContent(post.getContent());
            if (post.getImageUrl() != null) {
                builder.setImageUrl(post.getImageUrl());
            }

            if (post.getTotalLike() != null) {
                builder.setLike(post.getTotalLike());
            }

            if (post.getTotalLike() != null) {
                builder.setSubscribe(post.getTotalLike());
            }

            PostResponse response = builder.build();
            postResponses.add(response);
        });

        return postResponses;
    }
}
