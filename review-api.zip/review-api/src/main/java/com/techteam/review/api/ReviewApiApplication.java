package com.techteam.review.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(ReviewApiApplication.class, args);
    }
}
