package com.techteam.review.api.grpc.services;

import com.techteam.review.api.RepeatStreamResponse;
import com.techteam.review.api.StreamRequest;
import com.techteam.review.api.StreamResponse;
import com.techteam.review.api.StreamingServiceGrpc;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;

import java.util.ArrayList;
import java.util.List;

@GrpcService
public class StreamingServiceImpl extends StreamingServiceGrpc.StreamingServiceImplBase {
    @Override
    public void serverStream(StreamRequest request, StreamObserver<StreamResponse> responseObserver) {
        for(int i = 0; i < 1000; i++) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            StreamResponse response = StreamResponse.newBuilder().setId(i).setRequestId(request.getId()).build();
            responseObserver.onNext(response);

        }

        responseObserver.onCompleted();
        System.out.println("Done!");
    }

    @Override
    public StreamObserver<StreamRequest> clientStream(StreamObserver<RepeatStreamResponse> responseObserver) {
        List<StreamResponse> streamResponses = new ArrayList<>();
        return new StreamObserver<StreamRequest>() {
            @Override
            public void onNext(StreamRequest streamRequest) {
                streamResponses.add(StreamResponse.newBuilder().setId(1).setRequestId(streamRequest.getId()).build());
            }

            @Override
            public void onError(Throwable throwable) {

            }

            @Override
            public void onCompleted() {
                RepeatStreamResponse responses = RepeatStreamResponse.newBuilder().addAllResponses(streamResponses).build();
                responseObserver.onNext(responses);
                responseObserver.onCompleted();
            }
        };
    }

    @Override
    public StreamObserver<StreamRequest> bidirectionalStream(StreamObserver<StreamResponse> responseObserver) {
        return new StreamObserver<StreamRequest>() {
            @Override
            public void onNext(StreamRequest streamRequest) {
                for(int i = 0; i < 5; i++) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    StreamResponse response = StreamResponse.newBuilder().setId(i).setRequestId(streamRequest.getId()).build();
                    responseObserver.onNext(response);
                }
            }

            @Override
            public void onError(Throwable throwable) {

            }

            @Override
            public void onCompleted() {
                responseObserver.onCompleted();
            }
        };
    }
}
