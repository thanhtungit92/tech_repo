package com.techteam.review.api.grpc.services;

import com.techteam.review.api.*;
import com.techteam.review.api.services.PostService;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;
import org.springframework.beans.factory.annotation.Autowired;

@GrpcService
public class PostServiceImpl extends PostServiceGrpc.PostServiceImplBase {
    @Autowired
    private PostService postService;

    @Override
    public void create(PostRequest request, StreamObserver<PostResponse> responseObserver) {

        responseObserver.onNext(postService.createPost(request));
        responseObserver.onCompleted();
    }

    @Override
    public void update(PostRequest request, StreamObserver<PostResponse> responseObserver) {
        responseObserver.onNext(postService.updatePost(request));
        responseObserver.onCompleted();
    }

    @Override
    public void delete(PostDeleteRequest request, StreamObserver<Response> responseObserver) {
        responseObserver.onNext(postService.deletePost(request));
        responseObserver.onCompleted();
    }

    @Override
    public void getPosts(PostQuery request, StreamObserver<RepeatPostResponse> responseObserver) {
        RepeatPostResponse response = RepeatPostResponse.newBuilder().addAllResponses(postService.getAllPosts(request)).build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }
}
