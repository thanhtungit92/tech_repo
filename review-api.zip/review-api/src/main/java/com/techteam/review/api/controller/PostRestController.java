package com.techteam.review.api.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.techteam.review.api.PostQuery;
import com.techteam.review.api.rest.response.PostResp;
import com.techteam.review.api.services.PostService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.stream.Collectors;

@RestController
@RequestMapping("/post")
@Slf4j
public class PostRestController {
    @Autowired
    private PostService postService;

    @GetMapping(path = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getPosts() {
        return ResponseEntity.ok(postService.getAllPosts(PostQuery.newBuilder().build()).stream().map(x -> new PostResp(x)).collect(Collectors.toList()));
    }
}
