package com.techteam.review.api.rest.response;

import com.techteam.review.api.PostResponse;
import lombok.Data;

@Data
public class PostResp {
    private Long id;
    private String topic;
    private String content;
    private String imageUrl;
    private Long like;
    private Long subscribe;
    public PostResp(PostResponse postResponse) {
        id = postResponse.getId();
        topic = postResponse.getTopic();
        content = postResponse.getContent();
        imageUrl = postResponse.getImageUrl();
        like = postResponse.getLike();
        subscribe = postResponse.getSubscribe();
    }
}
